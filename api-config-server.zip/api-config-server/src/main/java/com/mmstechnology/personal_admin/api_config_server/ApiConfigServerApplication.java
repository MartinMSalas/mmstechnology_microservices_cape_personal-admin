package com.mmstechnology.personal_admin.api_config_server;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiConfigServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApiConfigServerApplication.class, args);
	}

}
