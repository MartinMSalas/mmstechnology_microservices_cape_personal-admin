package com.mmstechnology.personal.repository;

import com.mmstechnology.personal.model.SituacionLaboral;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SituacionLaboralRepository extends JpaRepository<SituacionLaboral, Long> {}
